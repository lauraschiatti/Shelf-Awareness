module.exports = [{
    comment: 'Great book',
    user: 'jefimija.zivkovic@mail.polimi.it',
    book: 'Misery'
  },
  {
    comment: 'Amazing',
    user: 'jefimija.zivkovic@mail.polimi.it',
    book: 'Il deserto dei tartari'
  },
  {
    comment: 'An awesome fantasy book',
    user: 'ana.pesko@mail.polimi.it',
    book: 'Wizard\'s First Rule'
  },
  {
    comment: 'A snake appears - did not like it',
    user: 'jefimija.zivkovic@mail.polimi.it',
    book: 'Harry Potter and the Philosopher\'s Stone'
  },
  {
    comment: 'Loved it',
    user: 'ana.pesko@mail.polimi.it',
    book: 'Harry Potter and the Philosopher\'s Stone'
  },
  {
    comment: 'It was ok',
    user: 'laura.siso@mail.polimi.it',
    book: 'Harry Potter and the Philosopher\'s Stone'
  },
  {
    comment: 'My favourite childhood book',
    user: 'ana.pesko@mail.polimi.it',
    book: 'In Dessert and Wilderness'
  }
];