module.exports = [{
    name: 'Ana Pesko',
    email: 'ana.pesko@mail.polimi.it',
    password: 'pass',
    address: 'Via Edoardo Bassini 23',
    creditcard: 'SBHJ'
  },
  {
    name: 'Jefimija Zivkovic',
    email: 'jefimija.zivkovic@mail.polimi.it',
    password: 'pass',
    address: 'Viale Romagna 62',
    creditcard: 'GFHK'
  },
  {
    name: 'Laura Schiatti Siso',
    email: 'laura.siso@mail.polimi.it',
    password: 'pass',
    address: 'Piazza Leonardo da Vinci 32',
    creditcard: 'HKJH'
  }
];