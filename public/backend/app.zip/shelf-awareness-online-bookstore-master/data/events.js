module.exports = [{
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2017-05-06 15:00:00',
    book: 'Misery'
  },
  {
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2018-06-10 15:00:00',
    book: 'Il deserto dei tartari'
  },
  {
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2019-03-03 15:00:00',
    book: 'Wizard\'s First Rule'
  },
  {
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2019-06-30 15:00:00',
    book: 'Phantom'
  },
  {
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2019-06-25 15:00:00',
    book: 'Harry Potter and the Order of the Phoenix'
  },
  {
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2019-07-30 15:00:00',
    book: 'Misery'
  },
  {
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2019-07-08 15:00:00',
    book: 'Harry Potter and the Deathly Hallows'
  },
  {
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2019-07-15 15:00:00',
    book: 'In Dessert and Wilderness'
  },
  {
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2019-07-10 15:00:00',
    book: 'Harry Potter and the Chamber of Secrets'
  },
  {
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2019-07-03 15:00:00',
    book: 'Confessor'
  },
  {
    location: 'La Feltrinelli Galleria Vittorio Emanuele',
    held_on: '2019-06-03 15:00:00',
    book: 'Harry Potter and the Half-Blood Prince'
  }
];
