module.exports = [{
    user: 'laura.siso@mail.polimi.it',
    book: 'Il deserto dei tartari',
    status: 'purchased',
    quantity: 4
  },
  {
    user: 'jefimija.zivkovic@mail.polimi.it',
    book: 'Misery',
    status: 'purchased',
    quantity: 4
  },
  {
    user: 'ana.pesko@mail.polimi.it',
    book: 'Harry Potter and the Philosopher\'s Stone',
    status: 'added',
    quantity: 1
  },
  {
    user: 'ana.pesko@mail.polimi.it',
    book: 'In Dessert and Wilderness',
    status: 'added',
    quantity: 1
  },
  {
    user: 'ana.pesko@mail.polimi.it',
    book: 'Wizard\'s First Rule',
    status: 'added',
    quantity: 1
  }
];
