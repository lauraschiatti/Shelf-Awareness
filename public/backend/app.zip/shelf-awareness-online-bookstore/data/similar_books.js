module.exports = [{
  book_1: 'Harry Potter and the Philosopher\'s Stone',
  book_2: 'Wizard\'s First Rule'
}];