module.exports = [{
    theme: 'Betrayal',
    book: 'In Dessert and Wilderness'
  },
  {
    theme: 'Survival',
    book: 'In Dessert and Wilderness'
  },
  {
    theme: 'Childhood',
    book: 'In Dessert and Wilderness'
  },
  {
    theme: 'Treachery',
    book: 'Wizard\'s First Rule'
  },
  {
    theme: 'Magic',
    book: 'Wizard\'s First Rule'
  },
  {
    theme: 'Love',
    book: 'Wizard\'s First Rule'
  },
  {
    theme: 'Magic',
    book: 'Phantom'
  },
  {
    theme: 'Magic',
    book: 'Confessor'
  },
  {
    theme: 'Magic',
    book: 'Harry Potter and the Philosopher\'s Stone'
  },
  {
    theme: 'Magic',
    book: 'Harry Potter and the Chamber of Secrets'
  },
  {
    theme: 'Magic',
    book: 'Harry Potter and the Prisoner of Azkaban'
  },
  {
    theme: 'Love',
    book: 'Harry Potter and the Goblet of Fire'
  },
  {
    theme: 'Sacrifice',
    book: 'Harry Potter and the Order of the Phoenix'
  },
  {
    theme: 'Sacrifice',
    book: 'Harry Potter and the Half-Blood Prince'
  },
  {
    theme: 'Sacrifice',
    book: 'Harry Potter and the Deathly Hallows'
  },
  {
    theme: 'Survival',
    book: 'Misery'
  },
  {
    theme: 'Survival',
    book: 'Il deserto dei tartari'
  }
];
