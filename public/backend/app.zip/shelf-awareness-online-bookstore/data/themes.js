module.exports = [{
    theme: 'Love'
  },
  {
    theme: 'War'
  },
  {
    theme: 'Revenge'
  },
  {
    theme: 'Betrayal'
  },
  {
    theme: 'Survival'
  },
  {
    theme: 'Grace'
  },
  {
    theme: 'Isolation'
  },
  {
    theme: 'Childhood'
  },
  {
    theme: 'Forgiveness'
  },
  {
    theme: 'Treachery'
  },
  {
    theme: 'Peace'
  },
  {
    theme: 'Magic'
  },
  {
    theme: 'Mythology'
  },
  {
    theme: 'Sacrifice'
  }
];
